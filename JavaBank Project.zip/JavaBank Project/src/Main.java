

/*
 * Copyright (c) 2020 Lorenzo Romio. All Right Reserved.
 */

public class Main {
    public static void main(String[] args) {





//        new WebApp("luca.armaroli","kiara4Lif3!");
        new WebApp();
        new WebApp("lorenzo.romio", "Burton86!");

    }
}
