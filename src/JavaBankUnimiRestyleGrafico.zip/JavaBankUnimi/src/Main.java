

/*
 * Copyright (c) 2020 Lorenzo Romio. All Right Reserved.
 */

public class Main {

    public static void main(String[] args) {

//            DBConnect.deleteAll();
//        DBConnect.populateDB();


//        new WebApp("luca.armaroli","kiara4Lif3!");
//        new WebApp();
        new LoginForm("lorenzo.romio", "Burton86!");
//        new LoginForm("marco.anisetti", "Password20!");

//
    }
}
